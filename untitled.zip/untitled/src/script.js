// Simple log to test JS
console.log("Portfolio loaded.");
const tabButtons = document.querySelectorAll('.tab-button');
const tabContents = document.querySelectorAll('.tab-content');

tabButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Remove active from all buttons and contents
    tabButtons.forEach(btn => btn.classList.remove('active'));
    tabContents.forEach(tab => tab.classList.remove('active'));

    // Activate the clicked button and corresponding tab
    button.classList.add('active');
    document.getElementById(button.dataset.tab).classList.add('active');
  });
});
